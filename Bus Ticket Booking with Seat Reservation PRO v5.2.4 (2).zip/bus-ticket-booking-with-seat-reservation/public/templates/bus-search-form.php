<?php do_action('wbtm_before_search_form'); ?>
<div class="mage_default mage_form_inline">
    <h2><?php do_action('wbtm_search_form_title'); ?></h2>
    <?php do_action('wbtm_search_form'); ?>
</div>
<?php do_action('wbtm_after_search_form'); ?>