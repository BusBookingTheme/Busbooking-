<?php
get_header();
the_post();
echo __('404 not found', 'bus-ticket-booking-with-seat-reservation');
get_footer();