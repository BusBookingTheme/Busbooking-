<?php 
get_header();

echo 'Hello This is custom single Template for Video Caegory taxonomy';
get_footer();
?>