<div class='wbtm_next_days_tab'>
    <?php do_action('wbtm_bus_search_next_day_tab'); ?>
</div>