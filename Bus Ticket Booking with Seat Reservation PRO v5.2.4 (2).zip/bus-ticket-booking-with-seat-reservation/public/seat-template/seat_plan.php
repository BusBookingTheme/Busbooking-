<?php 
require_once(dirname(__FILE__) . "/seat_plan_1.php");
require_once(dirname(__FILE__) . "/seat_plan_2.php");
require_once(dirname(__FILE__) . "/seat_plan_3.php");
require_once(dirname(__FILE__) . "/global_seat_plan.php");